package test;

import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("DATA.in"));
        ArrayList<Pair> a = (ArrayList<Pair>) ois.readObject();
        ArrayList<Pair> res = new ArrayList<>();
        Map<Pair, Integer> myMap = new HashMap<>();
        for (Pair i : a) {
            if (i.getFirst() < i.getSecond()) {
                if (!myMap.containsKey(i)) {
                    myMap.put(i, 1);
                    res.add(i);
                }
            }

        }
        Collections.sort(res);
        for (Pair i : res)
            System.out.println(i);
    }
}
